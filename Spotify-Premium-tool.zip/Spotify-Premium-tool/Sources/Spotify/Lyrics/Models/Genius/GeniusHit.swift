import Foundation

struct GeniusHit: Decodable {
    var result: GeniusHitResult
}