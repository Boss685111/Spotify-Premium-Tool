import Foundation
import UIKit

@objc protocol SPTDisclosureAccessoryView {
    static func disclosureAccessoryView() -> UIView
}