import Foundation

struct GeniusSongResponse: Decodable {
    var song: GeniusSong
}