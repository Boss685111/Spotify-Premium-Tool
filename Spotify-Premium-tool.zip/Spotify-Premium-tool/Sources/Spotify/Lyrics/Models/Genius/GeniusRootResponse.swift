import Foundation

struct GeniusRootResponse : Decodable {
    var response: GeniusDataResponse?
}