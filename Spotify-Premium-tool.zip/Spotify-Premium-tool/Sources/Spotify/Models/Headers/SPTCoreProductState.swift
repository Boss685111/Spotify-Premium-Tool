import Foundation

@objc protocol SPTCoreProductState {
    func stringForKey(_ key: String) -> String
}