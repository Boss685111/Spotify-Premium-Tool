import Foundation

@objc protocol SPTEncoreTypeStyle {
    static func bodyMediumBold() -> SPTEncoreTypeStyle
}
