import Foundation

struct LyricsOptions: Codable, Equatable {
    var romanization: Bool
    var musixmatchLanguage: String
}
