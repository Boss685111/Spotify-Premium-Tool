import Foundation

struct LyricsLineDto {
    var content: String
    var offsetMs: Int?
}
