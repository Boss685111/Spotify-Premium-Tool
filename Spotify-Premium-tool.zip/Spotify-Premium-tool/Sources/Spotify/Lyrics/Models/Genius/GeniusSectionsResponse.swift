import Foundation

struct GeniusSectionsResponse: Decodable {
    var sections: [GeniusSection]
}
