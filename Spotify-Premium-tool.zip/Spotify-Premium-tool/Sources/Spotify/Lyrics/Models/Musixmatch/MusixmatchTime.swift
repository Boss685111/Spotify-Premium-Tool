import Foundation

struct MusixmatchTime: Decodable {
    var total: Float
}