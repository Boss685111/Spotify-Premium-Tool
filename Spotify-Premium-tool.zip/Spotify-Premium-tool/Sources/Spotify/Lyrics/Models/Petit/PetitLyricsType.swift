import Foundation

enum PetitLyricsType: Int, Codable {
    case notDetermined = 0
    case plain = 1
    case linesSynced = 2
    case wordsSynced = 3
}
