import Foundation

struct PetitLyricsWord: Codable {
    var starttime: Int
}
