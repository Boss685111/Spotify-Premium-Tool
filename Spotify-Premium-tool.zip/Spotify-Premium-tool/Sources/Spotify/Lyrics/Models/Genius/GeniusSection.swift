import Foundation

struct GeniusSection: Decodable {
    var hits: [GeniusHit]
}
