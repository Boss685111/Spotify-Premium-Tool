import Foundation

struct GeniusLyrics: Decodable {
    var plain: String
}