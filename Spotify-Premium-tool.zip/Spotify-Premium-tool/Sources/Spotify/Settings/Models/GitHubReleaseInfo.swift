import Foundation

struct GitHubReleaseInfo: Decodable {
    var tag_name: String
}
