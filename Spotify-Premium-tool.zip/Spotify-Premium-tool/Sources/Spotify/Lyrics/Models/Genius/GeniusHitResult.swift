import Foundation

struct GeniusHitResult: Decodable {
    var id: Int
    var title: String
    var artistNames: String
}
