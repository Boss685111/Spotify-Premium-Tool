import Foundation

enum LyricsRomanizationStatus {
    case romanized
    case canBeRomanized
    case original
}
