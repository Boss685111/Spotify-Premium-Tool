import Foundation

struct GeniusSong: Decodable {
    var lyrics: GeniusLyrics
    var language: String
}
